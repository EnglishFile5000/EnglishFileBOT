import os
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, FSInputFile
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
PDF_PATH = "english_tests.pdf"

logging.basicConfig(level=logging.INFO)

if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing")

bot = Bot(TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "🇬🇧 <b>EnglishFileBOT</b> ga xush kelibsiz!\n\n"
        "📚 Ingliz tili testlarini o‘rganish uchun /tests buyrug‘ini yuboring.\n"
        "Admin PDF test faylini botga yuborishi mumkin."
    )

@dp.message(Command("tests"))
async def send_tests(message: Message):
    if os.path.exists(PDF_PATH):
        await message.answer_document(
            FSInputFile(PDF_PATH),
            caption="📘 Ingliz tili testlari. Omad!"
        )
    else:
        await message.answer("Hozircha test PDF yuklanmagan. Keyinroq urinib ko‘ring.")

@dp.message(F.document)
async def receive_document(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("PDF yuklash faqat bot administratori uchun.")
        return
    doc = message.document
    if not doc.file_name.lower().endswith(".pdf"):
        await message.answer("Iltimos, PDF fayl yuboring.")
        return
    await bot.download(doc, destination=PDF_PATH)
    await message.answer("✅ PDF saqlandi. O‘quvchilar /tests orqali olishi mumkin.")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
