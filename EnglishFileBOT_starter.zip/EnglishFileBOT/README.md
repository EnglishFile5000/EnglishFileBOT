# EnglishFileBOT

Telegram bot starter: administrator PDF testlar faylini yuboradi, o‘quvchilar `/tests` orqali yuklab oladi.

## Ishga tushirish

1. Python 3.10+ o‘rnating.
2. `pip install -r requirements.txt`
3. `BOT_TOKEN` va `ADMIN_ID` muhit o‘zgaruvchilarini kiriting.
4. `python bot.py` buyrug‘ini bajaring.

**Muhim:** Telegram bot tokenini GitHub repository ichiga yozmang. Uni hostingdagi Environment Variables/Secrets bo‘limida saqlang.

`ADMIN_ID` — bot egasining Telegram raqamli ID raqami.
